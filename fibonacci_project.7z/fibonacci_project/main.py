from fibonacci.call import call_fib

if __name__ == "__main__":
    n = int(input("Введите номер числа Фибоначчи: "))
    call_fib(n)
