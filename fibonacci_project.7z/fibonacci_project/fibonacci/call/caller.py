from fibonacci import fibonacci

def call_fib(n: int):
    print(f"Число Фибоначчи №{n} равно {fibonacci(n)}")
